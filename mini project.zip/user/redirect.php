<center><img src="loading-wheel.gif" alt="loading" style="width:100px;height:100px;" ></center>
<center><p >Please Wait.....</center>
<center><p>Redirecting</center>
<?php
header("refresh:5;url='./recharge.php'");
?>