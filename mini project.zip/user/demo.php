<?php

 include('../conn.php');  

session_start();
?>
<?php  
							if (isset($_SESSION['userlogin']))
   {
      $name= $_SESSION['userlogin'];
	 
	
	  }
	  $query="select * from tbrc where name='$name'";
$result=mysqli_query($conn,$query);
			 while($row=mysqli_fetch_array($result))
			 {
			 $txn=$row[1];
			$num=$row[3];
			$type=$row[4];
			$oprtr=$row[5];
			$amt=$row[6]; 
		$status=$row[7];
			}
			?>
<?php
				require ('../fpdf.php');
$pdf=new FPDF();
$pdf->AddPage();
$pdf->SetFont("Arial","B",16);
$pdf->Cell(0,10,"BILL RECEIPT",1,1,"C");
$pdf->SetFont("Arial","",16);
$pdf->Cell(0,10,"              NAME:                   $name",0,1,"C");
$pdf->Cell(0,10,"Transaction number:                   $txn",0,1,"C");
$pdf->Cell(0,10,"              TYPE:                   $type",0,1,"C");
$pdf->Cell(0,10,"      Phone number:                   $num",0,1,"C");
$pdf->Cell(0,10,"       Amount paid:                   $amt",0,1,"C");
$pdf->Cell(0,10,"            status:                   $status",0,1,"C");
$pdf->SetFont("Arial","B",16);
$pdf->Cell(0,10,"Thank you for recharging with us!!!.Visit again!!",0,1,"C");

$pdf->Cell(0,10,"************",0,1,"C");
				$pdf->output();
?>