
<html>
<head>
	<meta charset="UTF-8">
	<title>Recharge Hub</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
<?php
session_start();
include('rcreg.php');
include('../conn.php');
?>
</head>
<body>
	<div id="background">
		<div id="page">
			<div id="header">
			<div align="right" ><?php if (isset($_SESSION['name']))
      echo "<font color='blue'>".$_SESSION['name']."</font><br><br>";
	  echo "<a href='../logout.php'><font color='#83f442'>LOGOUT</font></a>";
?>
</div>
				
				<div id="navigation">
					<ul>
						<li  class="selected">
							<a href="recharge.php">Mobile</a>
						</li>
						
						<li  >
						<a href="rchistory.php">History</a>
					</li >
					
					
						
					</ul>
				</div>
			</div>
			<div id="contents">
				<div class="box">
					<div>
					
						<div id="contact" class="body">
						<h1>Mobile Recharge</h1>

                        <form id="form2" name="form2" method="post" action="" style="margin:auto;">
						    
                            <table>
									<tbody>
									<tr>
									<td></td>
											<td>
											<input name="nam" type="hidden" value="<?php if (isset($_SESSION['userlogin'])){$name= $_SESSION['userlogin'];echo $name;}?>" class="txtfield"  />

										</td>
										</tr>
										<tr>
											<td> Mobile Number:</td>
											<td>
											 <input name="mnum" type="text" value="<?php if ((isset($mnum))&&($mnumErr==false)){echo $mnum;}?>" class="txtfield" required />
								  <span style="color:red; font-family:Times New Roman; font-size:12px;">*<?php echo $mnumErr;?></span>

										</td>
										</tr> 
										<tr>
											<td>Type: </td>
										<td>
										 <select name="typ" value="<?php if ((isset($typ))&&($typErr==false)){echo $typ;}?>"  class="txtfield" required>
                    <option value="">---Please Select Type---</option>
					<option value="PREPAID">PREPAID</option>
					<option value="POSTPAID">POSTPAID</option>
					</select>
						<span style="color:red; font-family:Times New Roman; font-size:12px;">*<?php echo $typErr;?></span>
										</td>
										</tr> 
										<tr>
											<td>Operator:  </td>
										<td>
										<select name="oprtr" value="<?php if ((isset($oprtr))&&($oprtrErr==false)){echo $oprtr;}?>"   class="txtfield" required>
                    <option value="">---Please Select Your Operator---</option>
        	        <?php
					 $query="select * from tboprtr";
					$result=mysqli_query($conn,$query);
					  while($array = mysqli_fetch_array($result))
			  {
				echo "<option value='$array[1]'>$array[1]</option>";
			  }
			  ?>
      	            </select>
                      <span style="color:red; font-family:Times New Roman; font-size:12px;">*<?php echo $oprtrErr;?></span>
										</td>
										</tr> 
										<tr>
											<td>Amount:</td>
											<td>
											<input name="rcamt" type="text" value="<?php if ((isset($rcamt))&&($rcamtErr==false)){echo $rcamt;}?>" class="txtfield" required />
                                	

										</td>
										</tr> 
										 <tr>
											<td></td>
											<td>
											<input name="next" type="submit" value="Next" class="btn" />
                                       <input name="cancel" type="reset" value="Reset" class="btn" />
										</td>
										</tr>
									</tbody>
								</table>
                             </form>
						
						<p><img src="images/rechargeimg.png" alt="Img"></p>
							<p><img src="images/banner.jpg" alt="Img"></p>	
						</div>
					</div>
				</div>
			</div>
		</div>
		
				
					
		
		<div id="footer">
			<div>
				<ul class="navigation">
				
						<li  class="active">
							<a href="recharge.php">Mobile</a>
						</li>
						
						<a href="rchistory.php">History</a>
					
						
					</ul>
				
			</div>
	</div>
</body>
</html>